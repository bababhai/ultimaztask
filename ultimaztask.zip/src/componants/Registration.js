import React, { useState } from "react";
import { Link } from "react-router-dom";
import InputText from "./input/InputText";
import SelectOption from "./input/SelectOption";
import axios from "axios";

function Registration() {
  const [formData, setFormData] = useState({});
  const {message, setMessage} = useState('');
 const onChangeFormInputs = (event) => {
//console.log('In Registration' , event);
    //setFormData({[event.target.name] : event.target.value});
    setFormData(prevState => ({
        ...prevState,
        [event.target.name]: event.target.value
     }));
 }
//console.log('formdata' , formData);
const submitHandler = (event) => {
    event.preventDefault();
    axios({
  
        // Endpoint to send files
        url: "https://lobster-app-ddwng.ondigitalocean.app/user/register",
        method: "POST",
        headers: {
    
          // Add any auth token here
          api_key: "Z9Q7WKEY7ORGBUFGN3EG1QS5Y7FG8DU29GHKKSZH",
        },
    
        // Attaching the form data
        data: formData,
      })
    
        // Handle the response from backend here
        .then((res) => {
            console.log('results' , res);
            if (res.data.status) {
                setMessage('User Registered Successfully!');
                sessionStorage.setItem('userData', res.data.message);
            }
         })
    
        // Catch errors if any
        .catch((err) => { });
    }

  return (
    <div>
      <div className="gen_form">
        <div>{message}</div>
        <form onSubmit={submitHandler}>
          <InputText placeholder="Full Name" name="full_name" type="text" onChangeFormInput={onChangeFormInputs} />
          <InputText placeholder="User Name" name="username" type="text" onChangeFormInput={onChangeFormInputs} />
          <InputText placeholder="Password" name="password" type="password" onChangeFormInput={onChangeFormInputs} />
          <SelectOption name="country_row_id" onChangeFormInput={onChangeFormInputs} />
          <InputText placeholder="Email Id" name="email_id" type="text" onChangeFormInput={onChangeFormInputs} />
          <InputText placeholder="Mobile Number" name="mobile_number" type="text" onChangeFormInput={onChangeFormInputs} />
 

          

          <div className="input_txt">
            <button type="submit">Register</button>
          </div>
        </form>
      </div>
      <p className="signuplink">
        already have account <Link to="/login">Login</Link> here!
      </p>
    </div>
  );
}

export default Registration;
