export const countries = {
    '101': 'India',
    '102':'UAE',
    '103':'Canada'
  };